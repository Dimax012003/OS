#include "lab3.h"

int main() {
    print_message();
    print_message();
    return 0;
}
